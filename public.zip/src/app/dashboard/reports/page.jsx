import ReportsPage from '@/app/components/dashboard/reports/ReportsPage'
import React from 'react'

const page = () => {
  return (
    <div className=''>
      <ReportsPage />
    </div>
  )
}

export default page