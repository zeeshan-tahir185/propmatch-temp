import ProportyAnalysis from '@/app/components/dashboard/property/ProportyAnalysis'
import React from 'react'

const page = () => {
  return (
    <div className=''>
      <ProportyAnalysis />
    </div>
  )
}

export default page
