import OutreachMessagesPage from '@/app/components/dashboard/outreach/OutreachMessagesPage'
import React from 'react'

const page = () => {
  return (
    <div className=''>
      <OutreachMessagesPage />
    </div>
  )
}

export default page