import LeadRankingPage from '@/app/components/dashboard/leads/LeadRankingPage'
import React from 'react'

const page = () => {
  return (
    <div className=''>
      <LeadRankingPage />
    </div>
  )
}

export default page