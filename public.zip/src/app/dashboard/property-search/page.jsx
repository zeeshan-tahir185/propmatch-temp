import PropertySearchPage from '@/app/components/dashboard/property/PropertySearchPage'
import React from 'react'

const page = () => {
  return (
    <div className=''>
      <PropertySearchPage />
    </div>
  )
}

export default page