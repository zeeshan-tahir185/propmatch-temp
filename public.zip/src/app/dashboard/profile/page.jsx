import UserProfilePage from "../../components/user/UserProfilePage";

export default function ProfilePage() {
    return <UserProfilePage />;
}